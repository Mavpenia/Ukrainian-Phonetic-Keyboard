								Reboot after installing the .exe file!



	This keyboard also has Cyrillic symbols for a number of other languages: Belarusian, Bulgarian, Serbian, Macedonian, Mongolian.



	If you need to see the keymap, please go to the 'Keymap Legend' Folder. There are pictures and an ASCII version of all the keyboard layers (it might come in handy since the MSKLC is not good at sizing stuff).



	This keyboard layout was created to help people who are familiar with QWERTY and want to keep the bulk of that muscle memory when typing in Ukrainian Cyrillic. Since I favoured the similarity to QWERTY more than ergonomics, some frequently used Ukrainian letters will be on the AltGr (+Shift) layer(s). 
This is the price you pay when creating a keyboard based on qwerty for another alphabet. If you have any ideas how to make it more fitting to your specific use case,
please go ahead and change it yourself. I am just giving you a little something so you don't start with a blank page. The source file for the keyboard is in the folder if you want to move stuff around without having to reboot your computer right off the gate. You will need the Microsoft Keyboard Layout Creator program installed though.



Also if you get confused with the amount of extra Cyrillic letters for other languages,
check out my other (not extended) Ukrainian Phonetic Keyboard on Github.



Hope this helps. 
Mavpenia </3